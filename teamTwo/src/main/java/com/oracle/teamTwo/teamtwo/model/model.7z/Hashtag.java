package com.oracle.teamTwo.teamtwo.model;

public class Hashtag {

	private String user_id_email;
	private String user_following;

	public String getUser_id_email() {
		return user_id_email;
	}

	public void setUser_id_email(String user_id_email) {
		this.user_id_email = user_id_email;
	}

	public String getUser_following() {
		return user_following;
	}

	public void setUser_following(String user_following) {
		this.user_following = user_following;
	}

}
