package com.oracle.teamTwo.teamtwo.model;

public class Follower {

	private String user_id_email;
	private String user_follower;

	public String getUser_id_email() {
		return user_id_email;
	}

	public void setUser_id_email(String user_id_email) {
		this.user_id_email = user_id_email;
	}

	public String getUser_follower() {
		return user_follower;
	}

	public void setUser_follower(String user_follower) {
		this.user_follower = user_follower;
	}

}
