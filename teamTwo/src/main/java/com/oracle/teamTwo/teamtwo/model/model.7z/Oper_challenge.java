package com.oracle.teamTwo.teamtwo.model;

public class Oper_challenge {

	private String user_id_email;
	private int chg_num;
	private int review_score_average;

	public String getUser_id_email() {
		return user_id_email;
	}

	public void setUser_id_email(String user_id_email) {
		this.user_id_email = user_id_email;
	}

	public int getChg_num() {
		return chg_num;
	}

	public void setChg_num(int chg_num) {
		this.chg_num = chg_num;
	}

	public int getReview_score_average() {
		return review_score_average;
	}

	public void setReview_score_average(int review_score_average) {
		this.review_score_average = review_score_average;
	}

}
