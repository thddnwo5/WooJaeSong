package com.oracle.teamTwo.teamtwo.model;

public class Hashtag2 {

	private String chg_num;
	private String hashtag_num;

	public String getChg_num() {
		return chg_num;
	}

	public void setChg_num(String chg_num) {
		this.chg_num = chg_num;
	}

	public String getHashtag_num() {
		return hashtag_num;
	}

	public void setHashtag_num(String hashtag_num) {
		this.hashtag_num = hashtag_num;
	}

}
