package com.oracle.teamTwo.teamtwo.model;

public class Main_category {

	private int lc_num;
	private int mc_num;
	private int sc_num;
	private String subject;

	public int getLc_num() {
		return lc_num;
	}

	public void setLc_num(int lc_num) {
		this.lc_num = lc_num;
	}

	public int getMc_num() {
		return mc_num;
	}

	public void setMc_num(int mc_num) {
		this.mc_num = mc_num;
	}

	public int getSc_num() {
		return sc_num;
	}

	public void setSc_num(int sc_num) {
		this.sc_num = sc_num;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

}
