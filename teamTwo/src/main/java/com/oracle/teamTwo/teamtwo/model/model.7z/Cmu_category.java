package com.oracle.teamTwo.teamtwo.model;

public class Cmu_category {

	private int b_c_num;
	private String b_subject;

	public int getB_c_num() {
		return b_c_num;
	}

	public void setB_c_num(int b_c_num) {
		this.b_c_num = b_c_num;
	}

	public String getB_subject() {
		return b_subject;
	}

	public void setB_subject(String b_subject) {
		this.b_subject = b_subject;
	}

}
