package com.oracle.teamTwo.teamtwo.model;

public class Like_chglist {

	private String user_id_email;
	private int chg_num;

	public String getUser_id_email() {
		return user_id_email;
	}

	public void setUser_id_email(String user_id_email) {
		this.user_id_email = user_id_email;
	}

	public int getChg_num() {
		return chg_num;
	}

	public void setChg_num(int chg_num) {
		this.chg_num = chg_num;
	}

}
