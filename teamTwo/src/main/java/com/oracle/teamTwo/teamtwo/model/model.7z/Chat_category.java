package com.oracle.teamTwo.teamtwo.model;

public class Chat_category {

	private int q_cnum;
	private int a_cnum;
	private String chat_subject;

	public int getQ_cnum() {
		return q_cnum;
	}

	public void setQ_cnum(int q_cnum) {
		this.q_cnum = q_cnum;
	}

	public int getA_cnum() {
		return a_cnum;
	}

	public void setA_cnum(int a_cnum) {
		this.a_cnum = a_cnum;
	}

	public String getChat_subject() {
		return chat_subject;
	}

	public void setChat_subject(String chat_subject) {
		this.chat_subject = chat_subject;
	}

}
