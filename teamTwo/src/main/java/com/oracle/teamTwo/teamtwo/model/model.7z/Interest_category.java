package com.oracle.teamTwo.teamtwo.model;

public class Interest_category {

	private String user_id_email;
	private int q_cnum;
	private int a_cnum;

	public String getUser_id_email() {
		return user_id_email;
	}

	public void setUser_id_email(String user_id_email) {
		this.user_id_email = user_id_email;
	}

	public int getQ_cnum() {
		return q_cnum;
	}

	public void setQ_cnum(int q_cnum) {
		this.q_cnum = q_cnum;
	}

	public int getA_cnum() {
		return a_cnum;
	}

	public void setA_cnum(int a_cnum) {
		this.a_cnum = a_cnum;
	}

}
