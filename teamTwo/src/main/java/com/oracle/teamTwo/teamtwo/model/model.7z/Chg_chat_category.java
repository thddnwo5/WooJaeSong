package com.oracle.teamTwo.teamtwo.model;

public class Chg_chat_category {

	private int chg_num;
	private int q_cnum;
	private int a_cnum;

	public int getChg_num() {
		return chg_num;
	}

	public void setChg_num(int chg_num) {
		this.chg_num = chg_num;
	}

	public int getQ_cnum() {
		return q_cnum;
	}

	public void setQ_cnum(int q_cnum) {
		this.q_cnum = q_cnum;
	}

	public int getA_cnum() {
		return a_cnum;
	}

	public void setA_cnum(int a_cnum) {
		this.a_cnum = a_cnum;
	}

}
